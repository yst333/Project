package com.springboot.cherish.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.springboot.cherish.impl.MemberService;
import com.springboot.cherish.model.MemberVO;

// @CrossOrigin : proxy역할과 비슷 백과 연결
@CrossOrigin
@Controller
public class MemberController {

	@Resource(name = "memberService")
	private MemberService memberService;
	
	/**
	 * 로그인
	 * @param memberVO
	 * @param request
	 * @param response
	 * @param session
	 * @param model
	 * @throws Exception
	 */
	@PostMapping(value = "/loginAction.do")
	public @ResponseBody String loginAction(@ModelAttribute("memberVO") MemberVO memberVO, HttpServletRequest request, HttpServletResponse response, HttpSession session, Model model) throws Exception{
		String result = "N";
		
		try {
			MemberVO resultVO = memberService.selectMemberByIdByPw(memberVO);
			
			// 로그인에 성공하고 멤버의 정보가 있다면, 멤버의 이름을 리턴 처리합니다.
			if(resultVO != null) {
				result = resultVO.getMemberName();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}	
}
