package com.springboot.cherish.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.cherish.impl.QuestionService;
import com.springboot.cherish.model.Question;

@RestController
@CrossOrigin(origins = "http://localhost:3000/")
@RequestMapping("/")
public class QuestionController {

	@Autowired
	private QuestionService questionService;
	
	@PostMapping(value = "/Faq")
	public void insert(@RequestBody Question question) {
		questionService.insert(question);
	}
	
}