package com.springboot.cherish.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "question")
@SequenceGenerator(
	     name="IDX_SEQ_Question",      // 시퀀스 생성기의 이름을 지정
	     sequenceName="IDX_SEQ_Question",   // 시퀀스의 이름을 지정 (IDX_SEQ)
	     initialValue=1,         
	     allocationSize=1      
	     )
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, 
			generator = "IDX_SEQ_Question" //시퀀스 매핑
			)
	@Column(name = "qno")
	private int qno;
	
	@Column(name = "type")
	private int type;
	
	@Column(name = "contactnumber")
	private String contactnumber;
	
	@Column(name = "writer")
	private String writer;

	@Column(name = "content")
	private String content;	
}
