package com.springboot.cherish.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "member")
public class MemberVO {

	@Id
	@Column(name = "MEMBER_ID", length=25)
	private String memberId;
	
	@Column(name = "member_password", nullable = false,length=150)
	private String memberPw;
	@Column(name = "member_name", nullable = false,length=25)
	private String memberName;	
	@Column(name = "member_nickname", nullable = false,length=25)
	private String memberNickname;	
	@Column(name = "member_email", nullable = false,length=25)
	private String memberEmail;	 
}
