package com.springboot.cherish.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "board")
@SequenceGenerator(
	     name="IDX_SEQ_BOARD",      // 시퀀스 생성기의 이름을 지정
	     sequenceName="IDX_SEQ_BOARD",   // 시퀀스의 이름을 지정 (IDX_SEQ)
	     initialValue=1,         
	     allocationSize=1      
	     )
public class Article {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, 
	generator = "IDX_SEQ_BOARD" //시퀀스 매핑
	)
	
	@Column(name = "bno", length = 10 , nullable = false)
	private int articleId;
	
	@Column(name = "title", length = 50, nullable = false)
	private String articleTitle;
	
	@Column(name = "content", length = 2000, nullable = false)
	private String articleContent;	
	
	@Column(name = "writer", length = 25, nullable = false)
	private String articleWriter;	
}
