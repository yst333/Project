package com.springboot.cherish.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.cherish.model.Question;
import com.springboot.cherish.repository.QuestionRepository;

@Service("questionService")

public class QuestionServiceImpl implements QuestionService {
	
	@Autowired
	private QuestionRepository dao;

	@Override
	public void insert(Question question) {
		dao.save(question);		
	}

}