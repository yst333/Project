package com.springboot.cherish.impl;

import java.util.List;

import com.springboot.cherish.model.Article;

public interface ArticleService {

	void insert(Article article);
	
	void update(Article article);
	
	void delete(Article article);
	
	Article select();
	
	List<Article> findAll();
	
}
