package com.springboot.cherish.impl;

import com.springboot.cherish.model.Question;

public interface QuestionService {

	void insert(Question question);

}
