package com.springboot.cherish.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.cherish.model.Article;

@Repository
public interface ArticleRepository extends JpaRepository<Article, Integer> {

	
	Article findTopByOrderByArticleIdDesc();
	
	Article save(Article article);
	
	void delete(Article article);
	

}