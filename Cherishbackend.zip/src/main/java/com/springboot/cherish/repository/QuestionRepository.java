package com.springboot.cherish.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springboot.cherish.model.Question;

@Repository
public interface QuestionRepository extends JpaRepository<Question, Integer> {

	Question save(Question question);
	

}