import React from "react";

const CommunityBoard = () => {
    return(
        <div>
            <h1>커뮤니티게시판(CommunityBoard)</h1>
            <p>이 프로젝트는 리액트 라우터 기초를 실행해 보는 예제 프로젝트입니다!</p>
        </div>
    );
};
export default CommunityBoard;