import React, { Component } from 'react';
import Container from 'react-bootstrap/Container';
import { Route,Link,Switch } from "react-router-dom";

import BoardService from './BoardService';
import ViewButton from './ViewButton';
import CommunityBanner from './CommunityBanner';
import '../css/community_banner.css';
import '../css/community.css';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';




class Community extends Component {
    constructor(props){
        super(props)
        // 1단계 소스 코딩
        this.state = {
            boards: [] //상태값을 보드 배열에 담기
        }
    }

        // 2단계 소스 코딩
        componentDidMount(){
            BoardService.getBoards().then((res) => {
                this.setState({boards: res.data});
            });
        }

    render() {
        return (
            <>
                <Container>
                    <CommunityBanner/>
                    <div className='table_why'>
                        <table className='table_list'>
                            <thead>
                            <Container >
                                        <Row className='table_thead'>
                                            <Col lg={1} md={1} sm={1} xs={1} className='No'>No</Col>
                                            <Col lg={4} md={4} sm={4} xs={4} className='Title'>Title</Col>
                                            <Col lg={6} md={6} sm={6} xs={6} className='Content'>Content</Col>
                                            <Col lg={1} md={1} sm={1} xs={1} className='Writer'>Writer</Col>
                                        </Row>
                                    </Container>
                            </thead>
                            <tbody className='table_tbody'>
                                {
                                    this.state.boards.map( //**map함수 메서드로 반복해서 여러개 가져온다. 
                                    board =>
                                    <Container  >
                                        <Row key = {board.articleId}>
                                            <Col lg={1} md={1} sm={1} xs={1} className='board1'>{board.articleId}</Col>
                                            <Col lg={4} md={4} sm={4} xs={4} className='board2'>{board.articleTitle}</Col>
                                            <Col lg={6} md={6} sm={6} xs={6} className='board3'>{board.articleContent}</Col>
                                            <Col lg={1} md={1} sm={1} xs={1} className='board4'>{board.articleWriter}</Col>
                                        </Row>
                                    </Container>
                                    )
                                }
                                
                            </tbody>
                        </table>

                    </div>
                        <ViewButton />
                        {/* <Link to="/">
                            <button type="button">처음으로!</button>
                        </Link> */}
                </Container>                
            </>
     );
   }
}


export default Community;