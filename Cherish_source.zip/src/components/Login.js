import axios from "axios";
import React from "react";
import '../css/login.css';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from "react-bootstrap/Button";
import { Input } from "reactstrap";



const Login = () => {

    const fn_signIn = () => {
        var submitYN = false;

        const memberId = document.getElementById('memberId').value;
        const memberPw = document.getElementById('memberPw').value;

        if(document.getElementById("memberId").value.length < 1){
            alert("아이디를 입력해 주세요!");
            document.getElementById("memberId").focus()
            return;
        }

        if(document.getElementById("memberPw").value.length < 1){
            alert("비밀번호를 입력해 주세요!");
            document.getElementById("memberPw").focus()
            return;
        }

        if(!submitYN){
            var submitYN = true;

            const form = new FormData()
            form.append('memberId', memberId)
            form.append('memberPw', memberPw)

            console.log("click login");
            console.log(memberId);
            console.log(memberPw);

            axios.post('http://localhost:9008/loginAction.do',
            form,{
                headers:{
                    'Content-type':'application/json',
                }
            }
            )
            .then((res) => {
                console.log(res.data);
                if(res.data != "N"){
                    alert(res.data + " 회원님, 환영합니다!");
                    // sessionStorage에 id 저장 처리함
                    sessionStorage.setItem("member_id", memberId);
                    // sessionStorage에 name 저장 처리함
                    sessionStorage.setItem("name", res.data);
                    document.location.href="/";
                } else{
                    alert("회원 정보가 없습니다!");
                    // 회원 가입 컴포넌트를 만들고, url을 /register로 설정했을 경우
                    // alert("회원 정보가 없습니다. 회원 가입을 해주시기 바랍니다!");
                    // document.location.href="/register";
                }
            })
            .catch()
        }

    }
    return (
        <>
           <div className="login_header">
                <p className="loginText">Login</p>
           </div>
           {/* https://react-bootstrap.netlify.app/docs/layout/grid */}
           <Container fluid="sm">
            <Row className="login_row">
                <Col md={{span:4, offset:4}} id="login_div" >
                {/* https://react-bootstrap.netlify.app/docs/forms/form-control */}                
            <Form id='loginForm'>
                <Form.Group className="form-group mb-4">
                {/* https://reactstrap.github.io/?path=/docs/components-forms--input */}
                 <Input type="id" id="memberId" placeholder="아이디를 입력해 주세요!" />
                </Form.Group>
                <Form.Group className="form-group mb-4">
                <Input type="password" id="memberPw" placeholder="비밀번호를 입력해 주세요!" />
                </Form.Group>
                <div className="form-group d-grid mb-2 md-4">
                    <Button id="id_btn" variant="primary" size="lg" onClick={fn_signIn} >로그인</Button>
                </div>
                <div>
                    <label>
                        <input type="checkbox" name="rememberMe" value="yes" /> Remember me
                    </label>
                </div>
                <div>
                    {/* <!-- separator --> */}
                    <div class="separator">
                        <p>OR</p>
                    </div>
        

                    <ul className="icon">
                        {/* <li className="youtube">
                            <a href="#"><img src="/images/youtube.svg" alt="유튜브"></img></a>
                        </li> */}
                         <li className="facebook">
                            <a href="#"><img src="/images/facebook.svg" alt="페이스북"></img></a>
                        </li> 
                        <li className="naver">
                            <a href="#"><img src="/images/naver.svg" alt="naver"></img></a>
                        </li> 
                         <li className="kakao">
                            <a href="#"><img src="/images/kakao.svg" alt="카카오"></img></a>
                        </li> 
                    </ul>


{/*                     
                    <div className="form-group d-grid mb-2 md-3">
                        
                        <Button id="id_btn1" variant="primary" size="lg">
                            
                           
                            Sign in with Google
                        </Button>
                    </div>
                    <div className="form-group d-grid mb-2 md-3">
                        <Button id="id_btn2" variant="primary" size="lg">
       
                            Sign in with GitHub
                        </Button>
                    </div> */}
                </div>
            </Form>
                </Col>
            </Row>
           
           </Container>
        </>
    );
};

export default Login;



 {/* <i class="icon1 fa-brands fa-google"></i> */}

                     {/* <i class="icon2 fa-brands fa-github"></i> */}