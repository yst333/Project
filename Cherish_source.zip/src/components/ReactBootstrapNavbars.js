import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import Form from 'react-bootstrap/Form';
import Button from 'react-bootstrap/Button';
import React, { useState, useEffect } from "react";
import "../css/common.css";

// react-bootstrap/Navbar
// https://react-bootstrap.netlify.app/docs/components/navbar/

function ReactBootstrapNavbars() {
   // 로그인, 로그아웃
   const [isLogin, setIsLogin] = useState(false);
   const name = sessionStorage.name;
 
   // 로그인 상태 관리
   useEffect(()=>{
     if(sessionStorage.getItem('member_id') === null){
       console.log('isLogin 상태 = ', isLogin);
     } else {
       // 로그인 상태 변경
       setIsLogin(true);
       console.log('isLogin 상태 = ', isLogin);
     }
   });
 
   const onLogout = () => {
     alert("로그아웃 되셨습니다!");
     // sessionStorage에 저장되어 있는 아이템을 삭제 처리 합니다.
     sessionStorage.removeItem('member_id');
     sessionStorage.removeItem('name');
 
     // '/' url로 이동 처리함(새로고침)
     document.location.href = '/';
   }
   
  return (
    <>
      <div>
      <Navbar expand="lg"  className="navbarbg">
        <Container>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className='me-auto align-items-center' >
              <div className='ABOUT mx-3'><Nav.Link href="/About" >ABOUT</Nav.Link></div>
              <div className='GOODS mx-3'><Nav.Link href="/Goods/lights" >GOODS</Nav.Link></div>
              <div className='FAQs mx-3'><Nav.Link href="/Faq" >FAQs</Nav.Link></div>
              <div className='COMMUNITY mx-3'><Nav.Link href="/Community" >COMMUNITY</Nav.Link></div>     
              <Navbar.Brand href="/" className='logo'><img src='/images/navy.svg' alt='로고이미지' /></Navbar.Brand>
            </Nav>
            
              <Form className='d-flex align-items-center'>
                <div className='MY_Page mx-1'><Nav.Link href="/MY_Page" >MY PAGE</Nav.Link></div>
                <div className='JOIN mx-4'><Nav.Link href="/Join" >JOIN</Nav.Link></div>
                <div>
                  {isLogin
                  ? <div className='myLogout mx-1'>
                    {/* JSX는 javaScript이기 때문에 for 단어는 반복의 의미로 인식할 수 있습니다. 그래서, for 대신에 htmlFor을 사용해 주어야 합니다. */}
                    {/* 즉, 아래의 label 태그에서 for 속성 대신에 htmlFor 속성을 사용해 주어야 합니다. */}
                    <br></br>
                    <a id='logoutText' className='nav-link logout_link' onClick={onLogout} href='/'>LOGOUT</a>
                    <label className='welcome' htmlFor='logoutText'>{name}님 환영합니다!</label>
                    </div>
                  :
                    <a  className='nav-link login_link' role='button' href='/Login'>LOGIN</a>
                  }
                </div>
              </Form>
          </Navbar.Collapse>
        </Container>
      </Navbar>
      </div>
      </>
  );
}

export default ReactBootstrapNavbars;